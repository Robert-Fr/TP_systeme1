#ifndef __INTERFACE_RECHERCHE__
#define __INTERFACE_RECHERCHE__

void algo_principal(int parallelism, int *tableau, int taille, char *arg);

#endif
